# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/PyCQA/pylint/blob/main/LICENSE

__all__ = ("BaseWriter",)

from pylint.reporters.ureports.base_writer import BaseWriter
