__all__ = ['dentonm', 'test']
from .denton import dentonm
from statsmodels.tools._testing import PytestTester

test = PytestTester()
